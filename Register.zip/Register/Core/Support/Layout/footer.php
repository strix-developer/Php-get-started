  <footer>
        <div class="footer">
            <div class="mt-5 p-3 bg-dark text-white text-center">
                <h5>@All the Rights are reserved for Himanshu Thakur</h5>
            </div>
        </div>
    </footer>
