<?php

require_once __DIR__."/../Core/Support/kernel.php"
?>