 <?php
    require_once __DIR__ . "/../core/support/kernel.php";
    ?>