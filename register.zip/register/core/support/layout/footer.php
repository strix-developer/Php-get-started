
    <footer>
        <div class="container-fluid p-4 bg-dark text-success text-center rounded border border-danger border-5">
            <div class="row">
                <div class="cs-12">
                    <h3>
                        @All Rights Reserves Bootstrap
                    </h3>
                </div>
            </div>
        </div>
    </footer>
</body>

</html>