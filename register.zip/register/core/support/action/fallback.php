 <?php
    echo "<h4 class='error'>Error</h4>";
    ?>

 <!DOCTYPE html>
 <html lang="en">
 <style>
     .error {
         background-color: #4a4a4a;
         color: whitesmoke;
         text-align: center;
         height: 50px;
         padding-top: 7px;
         border-radius: 15px;
     }
 </style>

 </html>