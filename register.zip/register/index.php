 <?php

    require_once __DIR__ . "/bootstrap/app.php";

    require_once file_header();
    require_once file_content();
    require_once file_footer();
